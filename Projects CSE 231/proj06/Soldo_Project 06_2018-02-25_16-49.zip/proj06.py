CHROMOSOMES = ['chri','chrii','chriii','chriv','chrv','chrx']

def open_file():
    while True:
        prompt=input("Input a file name: ")
        try:
            fp= open(prompt,"r")                    # testing to see if correct input is found
            return fp
        except FileNotFoundError:                   # error if incorrect input is entered
            print("Unable to open the file. Please try again.")

def read_file(fp):
    genes_list=[]
    for line in fp:
        line=line.split()
        genes_list.append((line[0],int(line[3]),int(line[4])))
    genes_list.sort()
    return genes_list
       # print(Chrom_list,end=',')

def extract_chromosome(genes_list, chromosome):
    chrom_gene_list=[]
    for g in genes_list[0]:
        if genes_list== chromosome:
            chrom_gene_list.append(genes_list)
    print(genes_list[0])

def extract_genome(genes_list):
    ''' Docstring goes here.'''
    pass
    
def compute_gene_length(chrom_gene_list):
    ''' Docstring goes here.'''
    pass
 
def display_data(gene_list, chrom):
    ''' Docstring goes here.'''
	#"{:<11s}{:9.2f}{:9.2f}.format(name,list,SD)"
    pass
    
def main():
    fp=open_file()
    genes_list=read_file(fp)
    read_file(fp)
    extract_chromosome(genes_list, 'chrv')
    #"Gene length computation for C. elegans.\n"
    #"\nEnter chromosome or 'all' or 'quit': "
    #"\nChromosome Length")
    #"{:<11s}{:>9s}{:>9s}"
    #"Error in chromosome.  Please try again."


if __name__ == "__main__":
    main()
